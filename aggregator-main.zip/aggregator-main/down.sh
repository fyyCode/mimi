#!/bin/sh

git clone https://github.com/fyyCode/mimi.git
cd aggregator-main
pip install -r requirements.txt

python3 subscribe/collect.py -s

mv data/v2ray.txt ~/domains/566521a.serv00.net/public_html
