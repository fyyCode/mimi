#!/bin/sh

cd ~/sub
git clone https://github.com/fyyCode/mimi.git
cd mimi
unzip aggregator-main.zip
chmod -R 777 aggregator-main
cd aggregator-main
pip install -r requirements.txt

python3 subscribe/collect.py -s

mv data/v2ray.txt ~/domains/566521a.serv00.net/public_html

cd ~/sub
rm -rf mimi/
